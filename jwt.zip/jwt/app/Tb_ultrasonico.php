<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tb_ultrasonico extends Model
{
    //
}
