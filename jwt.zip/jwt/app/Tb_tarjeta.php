<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tb_tarjeta extends Model
{
    protected $fillable = [
        'nombre_ingreso'
    ];
}
