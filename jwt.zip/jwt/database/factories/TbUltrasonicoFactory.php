<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tb_ultrasonico;
use Faker\Generator as Faker;

$factory->define(Tb_ultrasonico::class, function (Faker $faker) {
    return [
        //
    ];
});
