<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tb_tarjeta;
use Faker\Generator as Faker;

$factory->define(Tb_tarjeta::class, function (Faker $faker) {
    return [
        //
    ];
});
