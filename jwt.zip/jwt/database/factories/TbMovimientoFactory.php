<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tb_movimiento;
use Faker\Generator as Faker;

$factory->define(Tb_movimiento::class, function (Faker $faker) {
    return [
        //
    ];
});
