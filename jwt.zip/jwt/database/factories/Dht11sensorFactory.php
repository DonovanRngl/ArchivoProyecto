<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\dht11sensor;
use Faker\Generator as Faker;

$factory->define(dht11sensor::class, function (Faker $faker) {
    return [
        //
    ];
});
