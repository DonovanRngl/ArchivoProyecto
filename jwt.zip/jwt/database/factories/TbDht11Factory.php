<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tb_dht11;
use Faker\Generator as Faker;

$factory->define(Tb_dht11::class, function (Faker $faker) {
    return [
        //
    ];
});
